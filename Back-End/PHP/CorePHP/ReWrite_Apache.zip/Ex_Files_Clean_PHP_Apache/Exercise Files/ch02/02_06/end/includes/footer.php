<footer>
  <p id="copyright" class="reset pull_out padding" role="contentinfo"><a
                href="http://www.ixd.hanselandpetal.com/">© 2013&ndash;<?= date('y'); ?>
    Hansel and Petal</a></p>
  <p id="disclaimer">Hansel &amp; Petal is a fictitious brand created by
    lynda.com solely for the purpose of training. All products and people
    associated with Hansel &amp; Petal are also fictitious. Any resemblance
    to real brands, products, or people is purely coincidental. Information
    provided about the product is also fictitious and should not be
    construed to be representative of actual products on the market in a
    similar product category.</p>
</footer>
